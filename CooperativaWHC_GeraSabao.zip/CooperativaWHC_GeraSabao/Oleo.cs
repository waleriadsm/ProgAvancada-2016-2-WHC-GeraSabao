﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CooperativaWHC_GeraSabao
{
    class Oleo : Produto
    {
        public Oleo(float peso) : base(peso)
        {

            this.Peso = peso;

        }
    }
}
