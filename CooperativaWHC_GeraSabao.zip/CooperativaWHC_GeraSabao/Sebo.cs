﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CooperativaWHC_GeraSabao
{
    class Sebo : Produto
    {
        public Sebo(float peso) : base(peso)
        {
            this.Peso = peso;
        }
    }
}
